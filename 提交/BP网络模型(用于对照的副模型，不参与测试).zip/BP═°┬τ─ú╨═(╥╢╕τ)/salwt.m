function salwt(layers_rec,weight_rec,theta_rec)
save('weight_rec.mat','weight_rec');
save('theta_rec.mat','theta_rec');
save('layers_rec.mat','layers_rec');
end