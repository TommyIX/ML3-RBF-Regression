function [weight,theta]=traonce(x,y,layers,weight,theta,vderei,eta)
[weight,theta]=backpropagation(x,y,layers,weight,theta,vderei,eta);
end
